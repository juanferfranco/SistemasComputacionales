#include "feature3.h"
#include <stdio.h>

void feature3(){
    // print hello from feature3
}
