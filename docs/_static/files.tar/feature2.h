#ifndef _FEATURE2_H
#define _FEATURE2_H
void feature2();
#endif