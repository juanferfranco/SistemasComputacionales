#include <stdio.h>
#include <stdlib.h>
#include "feature1.h"
#include "feature2.h"
#include "feature3.h"
#include "feature4.h"
#include "feature5.h"

int main(){
    feature1();
    feature2();
    feature3();
    feature4();
    feature5();
    return(EXIT_SUCCESS);
}