#include "feature1.h"
#include <stdio.h>

void feature1(){
    // print hello from feature1
}
