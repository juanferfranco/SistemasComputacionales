#ifndef _FEATURE1_H
#define _FEATURE1_H

void feature1();

#endif