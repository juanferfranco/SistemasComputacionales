#include "feature2.h"
#include <stdio.h>

void feature2(){
    // print hello from feature2
    
}
