#include "feature5.h"
#include <stdio.h>

void feature5(){
    // print hello from feature5
}
